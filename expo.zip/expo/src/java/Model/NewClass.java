/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 *
 * @author Shan
 */
public class NewClass {

    public static void main(String[] args) {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE, 7);
        Date d = c.getTime();
        System.out.println(new SimpleDateFormat("yyyy-MM-dd").format(d));

    }
}
