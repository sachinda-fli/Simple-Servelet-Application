package Model;


import java.util.Map;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Shan
 */
public class report {

    public JasperPrint getjasperprint(Map para, String path) {
        JasperPrint vc = null;

        try {
            JasperReport jr = JasperCompileManager.compileReport(path);
            vc = JasperFillManager.fillReport(jr, para, DBEXPO.getMyConnection());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return vc;
    }
}
