package Model;

import com.sun.mail.smtp.SMTPTransport;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.Message.RecipientType;
import javax.mail.Session;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 *
 * @author Shan
 */
public class e_mail {

    public static void e_mail_it(String email, String subject, String mess, String pat) throws javax.mail.MessagingException {
        try {
            String[] sender_email = {email};
            //String attachment = pat; attatching file path............
            String from = "";
            String pass = "";
            String host = "smtp.gmail.com";
            Properties prop = new Properties();
            prop = System.getProperties();
            prop.put("mail.smtp.starttls.enable", "true");
            prop.put("mail.smtp.host", host);
            prop.put("mail.smtp.socketFactory.port", 465);
            prop.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
            prop.put("mail.smtp.user", from);
            prop.put("mail.smtp.password", pass);
            prop.put("mail.smtp.port", 465);
            prop.put("mail.smtp.auth", "true");
            System.out.println("ok");
            Session ses = Session.getDefaultInstance(prop, null);
            javax.mail.internet.MimeMessage mm = new MimeMessage(ses);
            mm.setFrom(new InternetAddress(from));
            System.out.println("ok");
            InternetAddress[] ias = new InternetAddress[sender_email.length];
            for (int i = 0; i < sender_email.length; i++) {
                ias[i] = new InternetAddress(sender_email[i]);
            }
            System.out.println("ok");
            for (int i = 0; i < ias.length; i++) {
                mm.addRecipients(RecipientType.TO, ias);
            }
            mm.setSubject(subject);
            mm.setText(mess);
            //MimeBodyPart mbp=new MimeBodyPart();
            //mbp.attachFile(attachment);
            //Multipart mp=new MimeMultipart();
            //mp.addBodyPart(mbp);
            //mm.setContent(mp);
            //if you want to attach a file to this email first uncomment commented codes.then you can send a email with attachment.
            System.out.println("fine ok");
            SMTPTransport tran = (SMTPTransport) ses.getTransport("smtp");
            System.out.println("fine ok");
            tran.connect(host, 465, from, pass);
            tran.sendMessage(mm, mm.getAllRecipients());
            tran.close();
            System.out.println("Please Check Your email....");
        } catch (Exception ex) {
            Logger.getLogger(e_mail.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
