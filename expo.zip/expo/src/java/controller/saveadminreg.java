/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import Model.DBEXPO;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Shan
 */
public class saveadminreg extends HttpServlet {

   
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            String fullname = request.getParameter("fullname");
            String gender = request.getParameter("gender");
            String mobile = request.getParameter("mobile");
            String address = request.getParameter("address");
            String usertype = request.getParameter("usertype");
            String email = request.getParameter("email");
            String password = request.getParameter("password");

            DBEXPO.getMyConnection().createStatement().executeUpdate("insert into adminlog (email,password,full_name,gender,mobile,address,type,status) values('" + email + "','" + password + "','" + fullname + "','" + gender + "','" + mobile + "','" + address + "','" + usertype + "','1')");
            response.sendRedirect("admin_add_new_user.jsp?msg=New profile created successfully");
        } catch (Exception e) {
            throw new ServletException(e);
        }
    }

   
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

  
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

   
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
