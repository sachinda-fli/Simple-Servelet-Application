/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import Model.DBEXPO;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Shan
 */
public class admin_login extends HttpServlet {

    /**
     * Processes requests for both HTTP
     * <code>GET</code> and
     * <code>POST</code> methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            String email = request.getParameter("email");
            String pass = request.getParameter("pass");

            ResultSet getadmin = DBEXPO.getMyConnection().createStatement().executeQuery("select * from adminlog where email='" + email + "' AND password='" + pass + "' AND status='1'");
            if (getadmin.next()) {
                String type = getadmin.getString("type");
                String status = getadmin.getString("status");

                if (status.equals("1")) {

                    if (request.getParameter("check") != null) {
                        Cookie un = new Cookie("username", email);
                        Cookie pw = new Cookie("password", pass);

                        response.addCookie(un);
                        response.addCookie(pw);
                        HttpSession hs = request.getSession();
                        hs.setAttribute("type", type);
                        hs.setAttribute("result", getadmin);
                        hs.setAttribute("fullname", getadmin.getString("full_name"));
                        response.sendRedirect("adminhome.jsp");
                    } else {
                        HttpSession hs = request.getSession();
                        hs.setAttribute("type", type);
                        hs.setAttribute("result", getadmin);
                        hs.setAttribute("fullname", getadmin.getString("full_name"));
                        response.sendRedirect("adminhome.jsp");
                    }
                } else {
                    response.sendRedirect("Admin_Login.jsp?msg=You are deactivated.please contact the Administrator");
                }
            } else {
                response.sendRedirect("Admin_Login.jsp?msg=Wrong Username Or Password Entered Pleas Try Again.......");
            }
        } catch (Exception e) {
            throw new ServletException(e);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP
     * <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP
     * <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
