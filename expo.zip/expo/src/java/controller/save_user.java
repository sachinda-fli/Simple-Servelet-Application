/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Shan
 */
public class save_user extends HttpServlet {

    /**
     * Processes requests for both HTTP
     * <code>GET</code> and
     * <code>POST</code> methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            String first_name = request.getParameter("firstname");
            String last_name = request.getParameter("lastname");
            String email = request.getParameter("email");
            String telephone = request.getParameter("telephone");
            String fax = request.getParameter("fax");
            String address_one = request.getParameter("address1");
            String address_two = request.getParameter("address2");
            String city = request.getParameter("city");
            String post_code = request.getParameter("postcode");
            String country = request.getParameter("country");
            String password = request.getParameter("password");
            String check = request.getParameter("check");
            if (check != null) {
                Model.DBEXPO.getMyConnection().createStatement().executeUpdate("INSERT INTO user_reg (first_name,last_name,email,telephone,fax,address_one,address_two,city,post_code,country,password,status) VALUES('"+first_name+"','"+last_name+"','"+email+"','"+telephone+"','"+fax+"','"+address_one+"','"+address_two+"','"+city+"','"+post_code+"','Sri Lanka','"+password+"','1')");
                response.sendRedirect("Account_log.jsp");
            } else {
                response.sendRedirect("Register_Account.jsp");
            }


        } catch (Exception e) {
            throw new ServletException(e);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP
     * <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP
     * <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
