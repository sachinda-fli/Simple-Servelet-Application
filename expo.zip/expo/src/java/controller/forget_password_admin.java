package controller;

import Model.DBEXPO;
import Model.e_mail;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Shan
 */
public class forget_password_admin extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            String email = request.getParameter("email");
            String password = null;

            ResultSet getpass = DBEXPO.getMyConnection().createStatement().executeQuery("select * from adminlog where email='" + email + "'");
            while (getpass.next()) {
                password = getpass.getString("password");
            }

            new e_mail().e_mail_it(email, "EXPO Admin Password Recovery", "Your Password is :" +" "+ password, "");
            response.sendRedirect("Admin_Login.jsp?msg=Your old password emailed to your email.Please check your mails");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
